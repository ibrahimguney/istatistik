# B05 öğretim testi

Bu paket 10000 tekrarlı üstel öğretim örneğidir; 2000 tekrarlı ampirik
uygulama değildir. ZIP'i Tümünü ayıkla ile tamamen çıkarın.
Ayıklanan b05/ornek-01 klasöründe PowerShell açıp çalıştırın:

    py cozum.py --check

Beklenen: DOGRULANDI: 24 kontrol degeri eslesiyor.
--kur seçeneğini kullanmayın; özgün CSV ile karşılaştırıyoruz.
R kontrolü aynı klasörde: Rscript cozum.R --check --grafik
Rscript tanınmazsa hata mesajını paylaşın. Yalnız source kullanmak
--check ve --grafik seçeneklerini iletmez. Grafik histogram-r.png
olarak yazılır; aynı adlı eski grafiği korumak isterseniz önce kopyalayın.
SPSS çalışmanızı önce kaydedin. Çalışma dizinini veri.csv'nin bulunduğu
b05/ornek-01 klasörüne ayarlayıp analiz.sps dosyasının tamamını çalıştırın.
Üç histogram ve iki LIST tablosunu beklenen-sonuclar.csv ile karşılaştırın.
Özgün kaynak manifesti, üretim ve doğrulama kayıtları korunmuştur.
Bu kurtarma sırasında R/SPSS çalıştırılmadı; yeni başarı iddiası yoktur.
GitHub'a yüklemeyin; site aktarımı değil, yerel test paketidir.
