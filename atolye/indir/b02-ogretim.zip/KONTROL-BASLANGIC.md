# B02 — dört yapay kayıt için R/SPSS kullanıcı kontrolü

14 Eylül 2026. Bu bir test paketidir; canlı site güncellemesi değildir.
B01'in beş kayıtlı örneğini veya 395 kayıtlı gerçek veri uygulamasını
kullanmayın. Burada B02 için dört yapay öğrenci ve 23 kontrol değeri vardır.
R/SPSS kullanıcı kontrolü henüz tamamlanmadı.

## Paketi açın

Projedeki `yayin/B02-OGRETIM-TEST-OLUSTUR.py.txt` dosyasını indirin ve
indirdiğiniz klasörde çalıştırın:

```text
py B02-OGRETIM-TEST-OLUSTUR.py.txt
```

Yanında `b02-ogretim-test-v1.zip` oluşur. Üretici çevrimdışıdır; yalnız
ZIP yazar, analiz çalıştırmaz. ZIP'in tamamını yeni bir test klasörüne
çıkarın. B01 klasörüne birleştirmeyin. İçinde `b02/ornek-01` altında
`veri.csv`, `beklenen-sonuclar.csv`, `cozum.R`, `cozum.py` ve
`analiz.sps` birlikte bulunmalıdır. ZIP içinden tek dosya çalıştırmayın.

Paket 13 özgün dosya, değişmemiş `b02/MANIFEST.json` ve bu başlangıç
rehberini içerir. Eski README ve DOGRULAMA belgeleri tarihsel kayıttır;
bu teslim için örnek çalışma dizini **çıkarılan paketin `b02/ornek-01`
klasörüdür**, eski kitap dizini değildir. GitHub'a yüklemeyin.

## 1. R karşılaştırması

Açık çalışmalarınızı kaydedin; mümkünse ayrı temiz R oturumu kullanın.
R Console'da şu bloğu çalıştırın. Dosya seçicisi açılınca **bu yeni
paketin `b02/ornek-01/cozum.R` dosyasını** seçin:

```r
setwd(dirname(file.choose()))
stopifnot(all(file.exists(c("cozum.R", "veri.csv", "beklenen-sonuclar.csv"))))
source("cozum.R", echo = TRUE, encoding = "UTF-8")
beklenen <- read.csv("beklenen-sonuclar.csv", stringsAsFactors = FALSE)
stopifnot(nrow(sonuc) == 23L, nrow(beklenen) == 23L,
          identical(sonuc$degisken, beklenen$degisken),
          identical(sonuc$olcu, beklenen$olcu),
          isTRUE(all.equal(sonuc$deger, beklenen$deger,
                           tolerance = 1e-9, check.attributes = FALSE)))
cat("DOGRULANDI: 23 kontrol degeri eslesiyor.\n")
sessionInfo()
```

Rscript erişilebiliyorsa alternatif olarak `b02/ornek-01` klasöründe
`Rscript cozum.R --check` çalıştırılabilir. R Console'daki `source`
komutu tek başına `--check` çalıştırmaz; üstteki karşılaştırma bloğunu
atlamayın. Hata olursa durun ve ilk hata mesajını paylaşın.

Tam sonuç tablosunu, doğrulama mesajını ve `sessionInfo()` çıktısını
paylaşın. R'de başarı SPSS doğrulaması sayılmaz.

## 2. SPSS tabloları

R kontrolünden sonra **`b02/ornek-01` klasörünün tam Windows yolunu
paylaşın**; SPSS çalışma dizini bu yol olacak. Önce açık çalışmalarınızı
kaydedin, ayrı oturum kullanın. `analiz.sps` etkin veri kümesini,
filtre/ağırlık/split ayarlarını değiştirir. Doğru çalışma dizini
ayarlandıktan sonra `analiz.sps` dosyasının tamamı çalıştırılacaktır.

| Alan | Beklenen |
| --- | --- |
| Veri | 4 kayıt; okul_turu, sinif, puan |
| Ölçme düzeyleri | okul_turu Nominal; sinif Ordinal; puan Scale |
| Okul | Devlet 3 (%75); Ozel 1 (%25) |
| Sınıf 1/2/3 | Frekans 2/1/1; yüzde 50/25/25 |
| Puan | N=4, ortalama=74.5, minimum=68, maksimum=81 |
| Gruplara göre puan | Devlet N=3, ortalama=72.333333…; Ozel N=1, ortalama=81 |

SPSS betiği otomatik 23 satırlık doğrulama yapmaz; sözlük, frekans,
betimsel ve grup ortalaması tabloları karşılaştırılır. Görüntüleri ve
varsa uyarı/hataları paylaşın. Çıktıyı `b02-ogretim-spss-sonuc.spv`
gibi ayrı adla kaydedin; eski gerçek veri SPV'sinin üzerine yazmayın.

## Kapsam sınırı

Analiz kodları, veriler ve beklenen değerler değiştirilmedi. Yerel
dosya kurtarma yalnız özgün SHA-256 değerlerine ulaşan satır sonlarını
ve eksik SPSS dosyasının metin kopyasını kullanır. Bütünlüğün sağlanması
R/SPSS'in çalıştırıldığını göstermez. Bu ortamda R/SPSS yeniden
çalıştırılmadı; önceki 395 kayıtlı B02 çıktıları bu küçük örneğin kanıtı
değildir. B01 yayını, kitap metinleri ve kaynak paket değiştirilmez.
