GET DATA /TYPE=TXT /FILE='veri.csv' /ENCODING='UTF8'
 /ARRANGEMENT=DELIMITED /DELCASE=LINE /DELIMITERS="," /QUALIFIER='"'
 /FIRSTCASE=2 /VARIABLES=grup A12 sonuc A12 frekans F24.0.
DATASET NAME B12Hucreler.
FILTER OFF.
USE ALL.
WEIGHT OFF.
SPLIT FILE OFF.
VARIABLE LEVEL grup sonuc (NOMINAL) frekans (SCALE).
AGGREGATE OUTFILE=* MODE=ADDVARIABLES /BREAK=grup /satir_toplam=SUM(frekans).
AGGREGATE OUTFILE=* MODE=ADDVARIABLES /BREAK=sonuc /sutun_toplam=SUM(frekans).
AGGREGATE OUTFILE=* MODE=ADDVARIABLES /BREAK= /genel_toplam=SUM(frekans).
COMPUTE beklenen=satir_toplam*sutun_toplam/genel_toplam.
COMPUTE katki=(frekans-beklenen)**2/beklenen.
COMPUTE pearson_artik=(frekans-beklenen)/SQRT(beklenen).
COMPUTE satir_orani=frekans/satir_toplam.
FORMATS frekans beklenen katki pearson_artik satir_orani satir_toplam sutun_toplam genel_toplam (F16.10).
SORT CASES BY grup sonuc.
EXECUTE.
DISPLAY DICTIONARY.
LIST VARIABLES=grup sonuc frekans beklenen katki pearson_artik satir_orani satir_toplam sutun_toplam genel_toplam.
WEIGHT BY frekans.
CROSSTABS /TABLES=grup BY sonuc
 /FORMAT=AVALUE TABLES /STATISTICS=CHISQ PHI /CELLS=COUNT EXPECTED ROW SRESID.
WEIGHT OFF.
DATASET COPY B12Ozet.
DATASET ACTIVATE B12Ozet.
AGGREGATE OUTFILE=* /BREAK= /toplam=SUM(frekans) /ki_kare=SUM(katki) /min_beklenen=MIN(beklenen).
COMPUTE serbestlik=1.
COMPUTE p=SIG.CHISQ(ki_kare,serbestlik).
COMPUTE cramer_v=SQRT(ki_kare/toplam).
COMPUTE alfa=.05.
COMPUTE reddet=(p<alfa).
VALUE LABELS reddet 0 'H0 reddedilemez' 1 'H0 reddedilir'.
FORMATS toplam ki_kare serbestlik p cramer_v min_beklenen alfa (F16.10).
EXECUTE.
LIST VARIABLES=toplam ki_kare serbestlik p cramer_v min_beklenen alfa reddet.
DATASET ACTIVATE B12Hucreler.
WEIGHT OFF.
