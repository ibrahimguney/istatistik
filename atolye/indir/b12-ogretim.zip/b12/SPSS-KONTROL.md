# B12 — IBM SPSS 29 kontrolü

V1 kullanıcı çalıştırmasında analiz sonuçları uyumlu, dışa aktarım başarısızdı. V2 için 32 değerlik kabul bekliyor. [Düzeltme kaydı](SPSS-DUZELTME.md). Kontrol için:

1. ZIP'i tamamen ayıklayın; açık SPSS çalışmalarınızı kaydedin.
2. Syntax penceresinde gerçek klasörünüze göre `CD 'C:/.../b12/ornek-01'.` çalıştırın.
   Syntax dosyasını açmak çalışma klasörünü otomatik değiştirmez.
3. `spss-dogrula.sps` dosyasının tamamını çalıştırın. V2 dosyası analizi ve dışa aktarımı tek akışta yürütür; önce dört hücreyi, sonra tek özet satırını kaydeder. `veri.csv` aynı klasörden okunur. Hata/uyarıları inceleyin.
4. `spss-ozet.csv` ve `spss-satirlar.csv` dosyası oluşur.
   Önceki dışa aktarımlar varsa üzerlerine yazılır; analiz kaynakları değişmez.
5. Aynı `ornek-01` klasöründe terminal açıp çalıştırın:

   ```bash
   py spss_karsilastir.py --surum 29 --rapor spss-sonuc.json
   ```

   Gerçek sürüm numaranızı yazın. Yalnız Python standart kitaplığı gerekir.
   Beklenen: **GECTI: 32 kontrol**. Hatalı/eksik dışa aktarım başarı sayılmaz.
   Yeni denemede yeni rapor adı verin; mevcut raporun üzerine yazılmaz.
6. SPSS Viewer çıktısını `b12-spss.spv` ve mümkünse PDF olarak kaydedin.
   SPV, JSON raporu ve dışa aktarılan CSV'leri birlikte inceleme için paylaşın.

Karşılaştırma bağıl 1e-8 ve mutlak 1e-14 tolerans kullanır; SPSS dışa aktarımı
16 ondalıklı bilimsel gösterimle yapılır. Görüntüde yuvarlatılmış değerleri CSV'ye elle yazmayın.
Çok küçük p değerleri sıfır kabul edilmez. SPSS sürümü kullanıcı beyanıdır;
CSV'nin kökeni ve SPV uyarıları bu sayısal betik tarafından doğrulanmaz.
B12'de düzeltmesiz Pearson satırı esas alınır. B13'te REGRESSION yordamının
16 tahmini ve 16 artığı açık formül sonuçlarıyla ayrıca karşılaştırılır.

**Yorum:** CSV’de dört hücre vardır; katılımcı sayısı 80’dir. SPSS CROSSTABS sırasında frekans ağırlığı kullanılır ve sonra kapatılır. Pearson satırını karşılaştırın; Yates düzeltmesi veya Fisher testi başka bir hesap verir.
