# B04 — bağımsız öğretim testi V1

14 Eylül 2026. Bu paket yalnız {2,4,6,8} yapay evreninden geri koymalı
iki çekimin **16 sıralı sonucunu** içerir. 2000 tekrarlı gerçek veriye
dayalı benzetim, tam öğrenci sitesi veya GitHub aktarımı değildir.

## 1. ZIP'i oluşturun ve tamamını çıkarın

`B04-OGRETIM-TEST-OLUSTUR.py.txt` dosyasını bilgisayarınıza indirin.
Dosyanın bulunduğu klasörde terminal açıp çalıştırın:

```powershell
py B04-OGRETIM-TEST-OLUSTUR.py.txt
```

Üretici tek başına çalışır; internet veya ek Python paketi gerekmez.
Yanında `b04-ogretim-test-v1.zip` oluşturur. Analiz çalıştırmaz.
Aynı çıktı varsa korur; farklı mevcut çıktı varsa durur. Farklı dosyayı
silmek yerine üreticiyi ayrı boş klasörde çalıştırın.

ZIP'in **tamamını yeni bir klasöre çıkarın**. Kökünde bu rehberin
`KONTROL-BASLANGIC.md` kopyası, yanında `b04` klasörü bulunur.
18 dosya vardır: 16 özgün dosya, özgün manifest ve başlangıç rehberi.
Bu pakette `index.html` yoktur; GitHub'a yüklemeyin.

## 2. Python kontrolü

Çıkarılan paketin kökünde terminal açın:

```powershell
cd b04/ornek-01
py cozum.py --check --grafik
```

Analiz NumPy/pandas, grafik ayrıca Matplotlib ister; üretici bunları
kurmaz. Beklenen son kontrol mesajı:

```text
DOGRULANDI: 28 kontrol degeri eslesiyor.
```

`ciktilar/python/ornekleme-dagilimi.png` dosyasını açın. Grafik komutu
paketteki Python PNG'sini yeniden yazar; özgün ZIP'i arşiv olarak saklayın.
Yeniden üretilen PNG'nin bayt hash'i sürüme göre değişebilir. Sayısal
kontrol ile grafik incelemesi ayrı adımlardır. Terminalin tamamını ve
yazdırılan sürüm bilgisini saklayın; hata varsa sonraki adıma geçmeyin.

## 3. R kontrolü

RStudio çalışma dizinini çıkarılan `b04/ornek-01` klasörüne ayarlayın.
Konsolda `getwd()` ile kontrol edin; ardından:

```r
source("cozum.R")
kontrol_et(sonuc, read.csv("beklenen-sonuclar.csv", stringsAsFactors = FALSE))
grafik_kaydet(evren, veri)
sessionInfo()
```

Yalnız `source("cozum.R")` kontrolü ve grafiği çalıştırmaz. Kontrol
mesajında 28 eşleşme beklenir. R grafiği
`ciktilar/r/ornekleme-dagilimi.png` dosyasına yazılır.
Alternatif olarak aynı örnek klasöründe terminalden:

```powershell
Rscript cozum.R --check --grafik
```

`Rscript` bulunamazsa RStudio konsol yolunu kullanın. Konsol çıktısının
tamamını ve R grafiğini paylaşın; 2000 tekrarlı uygulamanın eski R çıktısı
bu küçük örneğin testi yerine geçmez.

## 4. SPSS tablo kontrolü

Açık çalışmalarınızı kaydedin; tercihen ayrı oturum kullanın. Çalışma
dizini çıkarılan `b04/ornek-01` olmalıdır. Sözdizimi dosyasını açmak
tek başına çalışma dizinini değiştirmez. `analiz.sps` dosyasının tamamını
çalıştırın; aynı içerikli `analiz.sps.txt` yedeği de pakettedir.
Betik etkin veri kümesini ve filtre/ağırlık/bölme ayarlarını değiştirir.

- Çapraz tabloda satır/sütun kategorileri 2,4,6,8; 16 hücrenin her biri
  **1**, genel toplam **16** olmalıdır. Fark varsa sonuçları kabul etmeyin.
- Liste çıktısını aşağıdaki değerlerle karşılaştırın. İki standart hata
  hesabı da 1,581139 göstermelidir; yanlılık 0 olmalıdır.
- Frequencies tablosunda 2–8 ortalamalarının frekansları 1,2,3,4,3,2,1
  olmalıdır. Yüzdeleri olasılıkla karşılaştırırken **100'e bölün**.
- Çapraz tablo, liste, frekans tablosu ve grafiği; mümkünse tam çıktı
  günlüğü ve SPSS sürümüyle birlikte saklayın.

SPSS için otomatik 28 değerlik `--check` yoktur. Ekran görüntüsü tam
günlük, sürüm veya dosya hash doğrulaması yerine geçmez.

## 5. Ortak beklenen sonuçlar ve grafik

| Ölçü | Beklenen |
| --- | ---: |
| Evren büyüklüğü N / çekim sayısı n / sıralı sonuç sayısı | 4 / 2 / 16 |
| Evren ortalaması | 5 |
| Evren varyansı / standart sapması | 5 / 2,236068 |
| Örneklem ortalamasının beklenen değeri | 5 |
| Tam örnekleme dağılımının varyansı | 2,5 |
| Standart hata | 1,581139 |
| P(ortalama >= 7) | 0,1875 |
| P(ortalama = 5) | 0,25 |

Python/R grafiğinin sol panelinde 2,4,6,8 değerlerinde dört eşit
0,25 olasılık çubuğu; sağ panelinde 2–8 değerlerinde
1/16,2/16,3/16,4/16,3/16,2/16,1/16 olasılıkları beklenir.
İki merkez de 5'tir. Bunlar ayrık olasılık çubuklarıdır; yoğunluk
histogramı değildir. SPSS grafiği yüzde ölçeğindedir; piksel eşitliği
beklenmez.

Tam dağılım varyansı hesaplanırken bölen 16'dır, 15 değil. Geri koymalı
çekimlerde sonlu evren düzeltmesi uygulanmaz. 16 satır 16 öğrenci değildir.
Alıştırmalardaki geri koymasız veya n=4 tasarımları ayrı sorulardır;
ana CSV ve beklenen sonuçları bunlara göre değiştirmeyin.

## Kanıt sınırı

Özgün manifest ve kaynak belgeler tarihsel içerikleriyle korunur.
Bu ek rehber bağımsız test paketinin çalışma dizinlerini açıklar.
Yerel Python denetimi R/SPSS'nin kullanıcı bilgisayarında çalıştırıldığı
anlamına gelmez. Bu teslim R/SPSS kabulü veya B04 yayın onayı değildir.
