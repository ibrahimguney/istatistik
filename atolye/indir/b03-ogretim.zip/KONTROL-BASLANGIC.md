# B03 — beş gözlemli öğretim testi

14 Eylül 2026. Bu paket yerel test içindir; site güncellemesi değildir.
B01/B02 klasörleriyle birleştirmeyin ve GitHub'a yüklemeyin.
395 kayıtlı gerçek veri uygulaması bu pakette bulunmaz.

## Paketi açma

Hazır ZIP: `yayin/b03-ogretim-test/b03-ogretim-test-v1.zip`.
ZIP'i indirin ve **tamamını ayrı bir klasöre çıkarın**. ZIP içinden dosya
çalıştırmayın. Örnek klasörü `b03/ornek-01` olup `veri.csv`, `cozum.R`,
`cozum.py`, `analiz.sps` ve `beklenen-sonuclar.csv` aynı yerde bulunmalıdır.

Doğrudan ZIP indirilemiyorsa yalnız `yayin/B03-OGRETIM-TEST-OLUSTUR.py.txt`
dosyasını indirin. Dosyanın bulunduğu klasörde şu komut aynı ZIP'i oluşturur:

```text
py B03-OGRETIM-TEST-OLUSTUR.py.txt
```

Üretici ek dosya, internet veya ek Python paketi istemez; gömülü ZIP'in
SHA-256 ve CRC kontrollerini yapar, analiz çalıştırmaz. Aynı adlı farklı
çıktının üzerine yazmaz. Bu korumayı kaldırmayın.

## Önce R kontrolü

Terminali çıkarılmış `b03/ornek-01` klasöründe açın:

```text
Rscript cozum.R --check --grafik
```

R konsolu kullanıyorsanız aşağıdaki ilk komutun açtığı pencereden bu
paketin **veri.csv** dosyasını seçin; ardından diğer satırları çalıştırın:

```r
setwd(dirname(file.choose()))
source("cozum.R")
kontrol_et(sonuc, read.csv("beklenen-sonuclar.csv", stringsAsFactors = FALSE))
grafik_kaydet(veri)
```

Beklenen mesaj: `DOGRULANDI: 26 kontrol degeri eslesiyor.`
Yeni R grafiği `ciktilar/r/betimsel-grafikler.png` altında oluşur.
Kontrol mesajını, `sessionInfo()` çıktısını ve bu grafiği paylaşın.
Bir hata olursa veri veya beklenen sonuç dosyasını değiştirmeyin;
ilk hata metnini paylaşın. Gerçek veriye ait eski `b03_R.txt` bu test değildir.

## Python kontrolü

Aynı örnek klasöründeki terminalde:

```text
py cozum.py --check --grafik
```

Beklenen mesaj yine 26 eşleşmedir. NumPy, pandas ve grafik için matplotlib
gerekir. Yeni grafik `ciktilar/python/betimsel-grafikler.png` dosyasının
yerine yazılır. Dağıtılan tarihsel PNG ile yeni üretimin baytları yazılım
sürümüne göre farklı olabilir; temiz ZIP'i saklayın, test çıktılarıyla
özgün manifesti yeniden yazmayın.

## Ardından SPSS kontrolü

1. Açık çalışmalarınızı kaydedin. SPSS çalışma dizinini bu yeni paketin
   `b03/ornek-01` klasörüne ayarlayın. Sözdizimini açmak dizini değiştirmez;
   evdeki eski klasör yolunu kullanmayın.
2. Paket içindeki `analiz.sps` dosyasının tamamını çalıştırın. Bu küçük
   örnek `veri.csv` dosyasını doğrudan okur; B01 SAV dosyası gerektirmez.
3. Şu değerleri karşılaştırın:

| Kontrol | Beklenen |
| --- | --- |
| Gözlem / eksik | 5 / 0 |
| 2, 3, 4, 13 saat sıklıkları | 1, 2, 1, 1 |
| Toplam / ortalama / medyan | 25 / 5 / 3 |
| Örneklem varyansı / standart sapması | 20,5 / yaklaşık 4,527693 |
| Kodun Q1 / Q3 / IQR listesi | 3 / 4 / 1 |
| Alt / üst aykırılık sınırı | 1,5 / 5,5 |
| Aykırı gözlem | Yalnız 13 saat |
| Geçici 13 hariç hesap: n / ortalama / medyan | 4 / 3 / 3 |

SPSS'te otomatik 26 satırlık kontrol yoktur. Tabloları, uyarıları ve
sözdizimi çalışma kaydını paylaşın; yalnız grafik yeterli değildir.
13 saat ana veriden silinmez; son hesap geçici duyarlılık karşılaştırmasıdır.

## Grafik ve kanıt sınırları

Python/R histogram sınıfları `[0,3)`, `[3,6)`, `[6,9)`, `[9,12)`, `[12,15]`;
frekanslar 1, 3, 0, 0, 1 olmalıdır. Kutu 3–4, medyan 3, bıyıklar 2 ve 4,
ayrı nokta 13 olmalıdır. SPSS otomatik histogram sınıfları ve yerleşik kutu
grafiği yöntemi farklı olabilir; kodun hesapladığı çeyrek listesini esas alın.
Grafikleri piksel eşitliğiyle değerlendirmeyin.

`b03/` altındaki özgün metinler tarihsel kayıttır. Dağıtımda 15 özgün
manifest girdisi, değişmeyen manifest ve bu rehber olmak üzere 17 dosya
bulunur. Eksik SPS dosyası yalnız metin yedeğinin özgün hash ile eşleşen
baytlarından geri kazanılır. Bu hazırlık R/SPSS'in burada yeniden
çalıştırıldığı veya B03'ün yayımlandığı anlamına gelmez.
